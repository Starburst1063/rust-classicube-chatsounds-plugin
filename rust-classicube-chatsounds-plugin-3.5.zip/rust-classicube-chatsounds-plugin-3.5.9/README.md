# rust-classicube-chatsounds-plugin

See [the latest GitHub release](https://github.com/SpiralP/rust-classicube-chatsounds-plugin/releases/latest) to download!
